package com.example.jilispringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiliSpringbootApplicationTests {

    @Test
    void contextLoads() {
    }

}
