package com.example.jilispringboot.service;

import java.util.List;

public interface ChartService {
    List getChartMapData();
}
